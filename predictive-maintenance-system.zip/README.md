# Sentinel — Predictive Maintenance

Sentinel est une interface de supervision de maintenance prédictive. Le frontend actuel est une interface Next.js de démonstration structurée pour être reliée à une API Spring Boot.

## Architecture cible

```text
React / Next.js (interface)
        ↓ REST + cookie HTTP-only
Spring Boot (API, sécurité, règles métier)
        ↓
PostgreSQL (machines, télémétrie, prédictions, alertes, historiques)
        ↑
Kafka (événements de télémétrie)

Python / Airflow / MLflow (features et prédictions)
```

Le modèle Python calcule les features et prédit `none`, `comp1`, `comp2`, `comp3` ou `comp4`. Spring Boot persiste et expose le résultat ; le frontend ne recalcule pas les features.

## Pages disponibles

- `/` — vue Overview
- `/machines` — parc machines et état opérationnel
- `/predictions` — risques composants sur 24 heures
- `/alerts` — alertes issues du seuil backend

Les routes dédiées redirigent vers l’interface avec la vue correspondante (`?view=machines`, `?view=predictions`, `?view=alerts`).

## Lancer le frontend actuel

Prérequis : Node.js 20+ et pnpm.

```bash
pnpm install
pnpm dev
```

Ouvrir `http://localhost:3000`. Pour vérifier la compilation :

```bash
pnpm build
```

## Liaison future avec Spring Boot

Créer un fichier `.env.local` :

```env
NEXT_PUBLIC_API_URL=http://localhost:8080/api
```

Le frontend devra appeler notamment :

```text
POST /auth/login
POST /auth/logout
GET  /auth/me
GET  /dashboard
GET  /machines
GET  /machines/{machineId}
GET  /predictions
GET  /alerts
GET  /machines/{machineId}/telemetry?range=24h
```

Les requêtes d’authentification doivent utiliser `credentials: 'include'` afin de conserver le cookie de session HTTP-only.

## PostgreSQL local

Créer la base et un utilisateur dédiés :

```sql
CREATE DATABASE predictive_maintenance;
CREATE USER sentinel WITH PASSWORD 'change-me-local';
GRANT ALL PRIVILEGES ON DATABASE predictive_maintenance TO sentinel;
```

Configuration Spring Boot attendue :

```env
SPRING_DATASOURCE_URL=jdbc:postgresql://localhost:5432/predictive_maintenance
SPRING_DATASOURCE_USERNAME=sentinel
SPRING_DATASOURCE_PASSWORD=change-me-local
SPRING_KAFKA_BOOTSTRAP_SERVERS=localhost:9092
FRONTEND_ORIGIN=http://localhost:3000
```

En production, ne pas committer les secrets. Utiliser les variables d’environnement du déploiement et des migrations Flyway versionnées.

## Ordre de démarrage cible

1. PostgreSQL et Kafka.
2. Spring Boot et ses migrations.
3. Le consumer Kafka de télémétrie.
4. Le pipeline Python/Airflow/MLflow.
5. Le frontend Next.js.

L’interface actuelle utilise encore des données de démonstration. La prochaine étape consiste à remplacer ces données par une couche API typée et à brancher l’authentification Spring Security, sans modifier le contrat métier des prédictions.
